var miSuma = (function() {
  var counter = parseInt(document.getElementById("numero").value);
  return function() {
    counter += 1;
    return (document.getElementById("salida").value = counter);
  };
})();

var miResta = (function() {
  var counter = parseInt(document.getElementById("numero").value);
  return function() {
    counter -= 1;
    return (document.getElementById("salida").value = counter);
  };
})();

function myFunction(valor) {
  switch (valor) {
    case "suma":
      miSuma();
      break;

    case "resta":
      miResta();
      break;
  }
}
