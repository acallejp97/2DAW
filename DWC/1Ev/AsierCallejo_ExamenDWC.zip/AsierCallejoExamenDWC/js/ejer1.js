//Parte 1
var frase = prompt("Ingrese la frase o palabra: ");
var numeroVocales = frase.match(/[aeiou]/gi).length;
alert("la frase tiene " + numeroVocales + " vocales");


//Parte 2
Palabra(frase);
var conseguirPalabras = new Palabras();
alert("La primera palabra es " + conseguirPalabras.primeraPalabra);
alert("La ultima palabra es " + conseguirPalabras.ultimaPalabra);

function Palabras() {}

function Palabra(fra) {
  convertirArray = fra.split("");
  Palabras.prototype.primeraPalabra = convertirArray[0];
  Palabras.prototype.ultimaPalabra = convertirArray[convertirArray.length - 1];
}

//Parte 3
alert(palindromo(frase));

function palindromo(fra) {
  var minuscula = fra.toLowerCase();
  var convertirArray = minuscula.split("");
  var sinEspacios = "";
  for (i in convertirArray) {
    if (convertirArray[i] != " ") {
      sinEspacios += convertirArray[i];
    }
  }
  var nuevoArray = sinEspacios.split("");
  var alReves = sinEspacios.split("").reverse();
  flag = true;
  for (i = 0; i < nuevoArray.length; i++) {
    if (nuevoArray[i] != alReves[i]) {
      flag = false;
      break;
    }
  }
  if (flag) {
    return "La cadena es un palíndromo.";
  } else {
    return "La cadena NO es un palíndromo.";
  }
}
