//Parte1
function soloLetras(e) {
  key = e.keyCode || e.which;
  tecla = String.fromCharCode(key).toLowerCase();
  letras = " áéíóúabcdefghijklmnñopqrstuvwxyz";
  especiales = "8-37-39-46";

  tecla_especial = false;
  for (var i in especiales) {
    if (key == especiales[i]) {
      tecla_especial = true;
      break;
    }
  }

  if (letras.indexOf(tecla) == -1 && !tecla_especial) {
    return false;
  }
}

function enfocado(id) {
  document.getElementById(id).style.backgroundColor = "#E0F8E6";
  document.getElementById(id).style.borderColor = "#000";
}

function desenfocado(id) {
  document.getElementById(id).style.backgroundColor = "#ffffff";
  document.getElementById(id).style.borderColor = "#5c5959";
}

//Parte 2
function fechaCarnet() {
  var aniosCarne = prompt("Inserte una fecha en formato dd/mm/yyyy");
  var aut = validarFecha(aniosCarne);
  while (aut != true) {
    alert("Fecha mal introducida");
    aniosCarne = prompt("Inserte una fecha en formato dd/mm/yyyy");
    aut = validarFecha(aniosCarne);
  }
  aniosCarne = ordenarFecha(aniosCarne);
  anios = calcularAnios(aniosCarne);
  if (anios <= 1) {
    document.getElementById("aniosCarnet").textContent =
      "Eres un CONDUCTOR NOVEL";
  } else {
    document.getElementById("aniosCarnet").textContent =
      "Eres un CONDUCTOR EXPERTO";
  }
  document.getElementById("aniosCarnet").hidden = false;
}

function ordenarFecha(fecha) {
  fecha = fecha.split("/");
  var month = fecha[1];
  var day = fecha[0];
  var year = fecha[2];

  var maxDias = 31;
  if (month == 4 || month == 6 || month == 9 || month == 11) maxDias = 30;
  if (month == 2) {
    if (year % 4 == 0) maxDias = 29;
    else maxDias = 28;
  }
  if ((month > 12 || month < 1) && (day > 31 || day < 1)) {
    return false;
  }
  if (day > maxDias) return false;
  var fechaOrdenada = month + "/" + day + "/" + year;
  return fechaOrdenada;
}

function calcularAnios(fecha) {
  var hoy = new Date();
  var cumpleanos = new Date(fecha);
  var anios = hoy.getFullYear() - cumpleanos.getFullYear();
  var m = hoy.getMonth() - cumpleanos.getMonth();

  if (m < 0 || (m === 0 && hoy.getDate() < cumpleanos.getDate())) {
    anios--;
  }

  return anios;
}

function validarFecha(fecha) {
  var fechaDividida = fecha.split("/");
  var month = fechaDividida[1];
  var day = fechaDividida[0];
  var year = fechaDividida[2];
  var maxDias = 31;
  if (month == 4 || month == 6 || month == 9 || month == 11) maxDias = 30;
  if (month == 2) {
    if (year % 4 == 0) maxDias = 29;
    else maxDias = 28;
  }
  if (month > 12 || month < 1) {
    return false;
  } else if (day > maxDias || day <= 0) {
    return false;
  } else {
    return true;
  }
}
